
<?php
/**
 * Plugin Name: WooCommerce Random Price Generator
 * Description: A plugin to generate random prices for WooCommerce products.
 * Version: 1.0
 * Author: Your Name
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Add menu item
add_action('admin_menu', 'wcrpg_add_menu_page');

function wcrpg_add_menu_page() {
    add_menu_page(
        'Random Price Generator',
        'Random Price Generator',
        'manage_options',
        'random-price-generator',
        'wcrpg_create_admin_page',
        'dashicons-admin-generic',
        56
    );
}

function wcrpg_create_admin_page() {
    ?>
    <div class="wrap">
        <h1>WooCommerce Random Price Generator</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Minimum Price</th>
                    <td><input type="number" name="wcrpg_min_price" step="0.01" required /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Maximum Price</th>
                    <td><input type="number" name="wcrpg_max_price" step="0.01" required /></td>
                </tr>
            </table>
            <?php submit_button('Generate Random Prices'); ?>
        </form>
    </div>
    <?php

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['wcrpg_min_price']) && isset($_POST['wcrpg_max_price'])) {
            $min_price = floatval($_POST['wcrpg_min_price']);
            $max_price = floatval($_POST['wcrpg_max_price']);
            wcrpg_generate_random_prices($min_price, $max_price);
        }
    }
}

function wcrpg_generate_random_prices($min_price, $max_price) {
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
    );
    $products = get_posts($args);

    foreach ($products as $product) {
        $random_price = rand($min_price * 100, $max_price * 100) / 100;
        update_post_meta($product->ID, '_regular_price', $random_price);
        update_post_meta($product->ID, '_price', $random_price);
    }

    echo '<div class="updated"><p>Random prices generated successfully.</p></div>';
}
?>
